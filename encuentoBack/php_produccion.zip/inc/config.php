<?php
define("DB_HOST", "localhost");
define("DB_USERNAME", "u977501569_contacto");
define("DB_PASSWORD", "Encuentro2022+");
define("DB_DATABASE_NAME", "u977501569_encuentroAsist");