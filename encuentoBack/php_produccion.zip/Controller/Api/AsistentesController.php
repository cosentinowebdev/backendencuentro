<?php
use PHPMailer\PHPMailer\PHPMailer;
class AsistentesController extends BaseController
{
    /**
     * "/asistentes/list" Endpoint - Get list of users
     */
    public function listAction()
    {
        $strErrorDesc = '';
        $requestMethod = $_SERVER["REQUEST_METHOD"];
        $arrQueryStringParams = $this->getQueryStringParams();
 
        if (strtoupper($requestMethod) == 'GET') {
            try {
                $asistentesModel = new AsistentesModel();
                $intLimit = 10;
                if (isset($arrQueryStringParams['limit']) && $arrQueryStringParams['limit']) {
                    $intLimit = $arrQueryStringParams['limit'];
                }
 
                $arrAsistentes = $asistentesModel->getAsistentes($intLimit);
                $responseData = json_encode($arrAsistentes);
            } catch (Error $e) {
                $strErrorDesc = $e->getMessage().'Something went wrong! Please contact support.';
                $strErrorHeader = 'HTTP/1.1 500 Internal Server Error';
            }
        }else {
            $strErrorDesc = 'Method not supported';
            $strErrorHeader = 'HTTP/1.1 422 Unprocessable Entity';
        }
 
        // send output
        if (!$strErrorDesc) {
            $this->sendOutput(
                $responseData,
                array('Content-Type: application/json', 'HTTP/1.1 200 OK')
            );
        } else {
            $this->sendOutput(json_encode(array('error' => $strErrorDesc)), 
                array('Content-Type: application/json', $strErrorHeader)
            );
        }
    }
        /**
     * "/asistentes/set" Endpoint - Get list of users
     */
    public function setAction()
    {
        $strErrorDesc = '';
        $requestMethod = $_SERVER["REQUEST_METHOD"];
        $arrQueryStringParams = $this->getQueryStringParams();
 
        if(strtoupper($requestMethod) == 'POST') {
            try {
                $asistentesModel = new AsistentesModel();

                $url= $_SERVER["REQUEST_URI"];
                $components = parse_url($url);
                parse_str($components['query'], $results);
                $aux=$asistentesModel->setAsistente($results);
                
                
                ini_set( 'display_errors', 1 );
                error_reporting( E_ALL );
                $from = "contacto@php.encuentrodeescritores.com.ar";
                $to = "no-responder@php.encuentrodeescritores.com.ar";
                $subject = "Checking PHP mail";
                $message = "PHP mail works just fine";
                $headers = "From:" . $from;
                mail($to,$subject,$message, $headers);
                    
                $mensaje=array('mail'=>true,'form'=>true);
                $responseData=json_encode($mensaje);
            } catch (Error $e) {
                $strErrorDesc = $e->getMessage().'Something went wrong! Please contact support.';
                $strErrorHeader = 'HTTP/1.1 500 Internal Server Error';
            }
        } else {
            $strErrorDesc = 'Method not supported';
            $strErrorHeader = 'HTTP/1.1 422 Unprocessable Entity';
        }
 
        // send output
        if (!$strErrorDesc) {
            $this->sendOutput(
                $responseData,
                array('Content-Type: application/json', 'HTTP/1.1 200 OK')
            );
        } else {
            $this->sendOutput(json_encode(array('error' => $strErrorDesc)), 
                array('Content-Type: application/json', $strErrorHeader)
            );
        }
    }
    public function sendMail()
    {

        require 'vendor/autoload.php';
        $mail = new PHPMailer;
        $mail->isSMTP();
        $mail->SMTPDebug = 2;
        $mail->Host = 'smtp.hostinger.com';
        $mail->Port = 465;
        $mail->SMTPAuth = true;
        $mail->Username = 'no-responder@encuentrodeescritores.com.ar';
        $mail->Password = 'Encuentro2022+';
        $mail->setFrom('no-responder@encuentrodeescritores.com.ar', 'Contacto');
        $mail->addReplyTo('contacto@encuentrodeescritores.com.ar', 'rodrigo');
        $mail->addAddress('contacto@encuentrodeescritores.com.ar', 'Receiver Name');
        $mail->Subject = 'Testing PHPMailer';
        $mail->msgHTML('<h1>un mensaje</h1>');
        $mail->Body = 'This is a plain text message body';
        //$mail->addAttachment('test.txt');
        if (!$mail->send()) {
            echo 'Mailer Error: ' . $mail->ErrorInfo;
        } else {
            echo 'The email message was sent.';
        }
    }
}